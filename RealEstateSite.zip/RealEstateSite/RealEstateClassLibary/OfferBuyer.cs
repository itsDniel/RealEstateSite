﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealEstateClassLibary
{
    public class OfferBuyer
    {
        public int homeid { get; set; }
        public string buyer { get; set; }
        public string buyername { get; set; }
        public int a1 { get; set; }
        public string a2 { get; set; }
        public string a3 { get; set; }
        public string status { get; set; }
        public int sellerStatus { get; set; }
        public int buyerStatus { get; set; }
    }
}
