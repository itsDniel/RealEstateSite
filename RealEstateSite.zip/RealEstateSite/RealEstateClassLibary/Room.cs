﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealEstateClassLibary
{
    public class Room
    {
        public Room() { }
        public int Id { get; set; }
        public String RoomName { get; set; }
        public int Width { get; set; }
        public int Length { get; set; }
    }
}
